const display = document.getElementById("xero-text");
const visual = document.getElementById("xero-visual");
document.getElementById("sendBtn").onclick = sendMessage;
document.getElementById("userInput").addEventListener("keydown", function(e){
    if(e.key==="Enter") sendMessage();
});
function sendMessage() {
    const input = document.getElementById("userInput");
    const text = input.value.trim();
    if(!text) return;
    currentMood = moodFromInput(text);
    xeroReply(text);
    input.value = "";
}
function xeroReply(userText) {
    let response;
    if(currentMood==="irritated" && (userText.includes("calm")||userText.includes("down"))) {
        response = pick(dialogue.angerTrigger);
        visual.style.boxShadow = "0 0 45px red";
        visual.style.background = "radial-gradient(circle, rgba(255,0,0,0.2), black)";
    } else {
        response = pick(dialogue[currentMood]);
        moodVisual();
    }
    display.textContent = response;
}
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
function moodVisual(){
    switch(currentMood){
        case "sad":
            visual.style.boxShadow = "0 0 45px #4455ff";
            visual.style.background = "radial-gradient(circle, rgba(80,80,255,0.2), black)";
            break;
        case "party":
            visual.style.boxShadow = "0 0 45px #ff00ff";
            visual.style.background = "radial-gradient(circle, rgba(255,0,255,0.2), black)";
            break;
        case "jam":
            visual.style.boxShadow = "0 0 45px #ff3300";
            visual.style.background = "radial-gradient(circle, rgba(255,100,0,0.2), black)";
            break;
        default:
            visual.style.boxShadow = "0 0 45px #00ff99";
            visual.style.background = "radial-gradient(circle, rgba(0,255,153,0.2), black)";
    }
}