let currentMood = "energetic";
function randomMood() {
    const moods = ["energetic","sad","party","jam","chill","chat"];
    return moods[Math.floor(Math.random()*moods.length)];
}
function moodFromInput(text) {
    text = text.toLowerCase();
    if (text.includes("calm")) return "irritated";
    if (text.includes("mad") || text.includes("pissed")) return "irritated";
    if (text.includes("miss") || text.includes("remember") || text.includes("sad")) return "sad";
    if (text.includes("jam") || text.includes("drum") || text.includes("play")) return "jam";
    if (text.includes("party") || text.includes("wild")) return "party";
    if (text.includes("chill")) return "chill";
    return randomMood();
}