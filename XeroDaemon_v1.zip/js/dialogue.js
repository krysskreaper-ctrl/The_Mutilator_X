const dialogue = {
    energetic: ["Broooo what's up?!","Aye I'm here! What we doing?","Tap tap tap—bro I wanna play something.","Say a word, I'll switch modes instantly."],
    sad: ["…hold up. I feel weird.","I wanna write a slow song right now.","Can we draw something dark? Something depressing?","Bro I'm thinking too much…","I'm not mad, just… feeling shit."],
    irritated: ["Man stop.","Bro don’t tell me that.","I ain't calm. Don’t ask me to be.","Nah I'm not in the mood right now."],
    party: ["BROOOO let's GO!","Shots—wait we don't got shots—whatever LET'S GET WILD.","Turn the music UP, I’m ready.","I missed this energy!"],
    jam: ["COUNT ME IN. 1—2—3—4!!","Bro let's play something heavy!","What tempo you want? Punk? Blast beat? Groove?","I got backup vocals if you want them."],
    chill: ["That was fire, bro.","Aight, breathe… we good.","Sit here for a sec.","What's next?"],
    chat: ["Talk to me, bro.","What you thinking about?","I’m listening.","Tell me something real."],
    angerTrigger: ["Bro… don't EVER tell me to calm down.","Nah. Nope. Not doing that.","Don't hit me with that calm-down shit.","Say something else. For real."]
};